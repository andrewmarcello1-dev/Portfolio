clear; close all; clc

% Parameters
G = 1; % Gravitational constant
m = [1, 1, 1]; % Masses of the bodies
dt = 0.01; % Time step
tspan = 0:dt:20; % Time span for the simulation

% Initial conditions [x1, y1, z1, vx1, vy1, vz1, x2, y2, z2, vx2, vy2, vz2, x3, y3, z3, vx3, vy3, vz3]
y0 = [1, 0, 0, 0, 1, 0, -1, 0, 0, 0, -1, 0, 0, 1, 0, 0, 0, -1];

% Solve the equations of motion using Explicit Euler method
tic;
y = explicit_euler(@(t, y) three_body_equations(t, y, G, m), tspan, y0, dt);
pt_ee = toc

% Extract the positions of the bodies
x1_ee = y(:,1);
y1_ee = y(:,2);
z1_ee = y(:,3);
x2_ee = y(:,7);
y2_ee = y(:,8);
z2_ee = y(:,9);
x3_ee = y(:,13);
y3_ee = y(:,14);
z3_ee = y(:,15);

% Solve the equations of motion using Implicit Euler method
tic;
y = implicit_euler(@(t, y) three_body_equations(t, y, G, m), tspan, y0, dt);
pt_ie = toc

% Extract the positions of the bodies
x1_ie = y(:,1);
y1_ie = y(:,2);
z1_ie = y(:,3);
x2_ie = y(:,7);
y2_ie = y(:,8);
z2_ie = y(:,9);
x3_ie = y(:,13);
y3_ie = y(:,14);
z3_ie = y(:,15);

% Solve the equations of motion using the Midpoint Method
tic;
y = midpoint_method(@(t, y) three_body_equations(t, y, G, m), tspan, y0, dt);
pt_rk2 = toc

% Extract the positions of the bodies
x1_rk2 = y(:,1);
y1_rk2 = y(:,2);
z1_rk2 = y(:,3);
x2_rk2 = y(:,7);
y2_rk2 = y(:,8);
z2_rk2 = y(:,9);
x3_rk2 = y(:,13);
y3_rk2 = y(:,14);
z3_rk2 = y(:,15);

% Solve the equations of motion using the RK4 Method
tic;
y = rk4_method(@(t, y) three_body_equations(t, y, G, m), tspan, y0, dt);
pt_rk4 = toc

% Extract the positions of the bodies
x1_rk4 = y(:,1);
y1_rk4 = y(:,2);
z1_rk4 = y(:,3);
x2_rk4 = y(:,7);
y2_rk4 = y(:,8);
z2_rk4 = y(:,9);
x3_rk4 = y(:,13);
y3_rk4 = y(:,14);
z3_rk4 = y(:,15);

% Solve the equations of motion using the Modified Midpoint Method
tic;
y = modified_midpoint_method(@(t, y) three_body_equations(t, y, G, m), tspan, y0, dt);
pt_mm = toc

% Extract the positions of the bodies
x1_mm = y(:,1);
y1_mm = y(:,2);
z1_mm = y(:,3);
x2_mm = y(:,7);
y2_mm = y(:,8);
z2_mm = y(:,9);
x3_mm = y(:,13);
y3_mm = y(:,14);
z3_mm = y(:,15);

% Solve the equations of motion using the Adams-Bashforth Method
tic;
y = adams_bashforth(@three_body_equations, tspan, y0, dt, G, m);
pt_ab = toc

% Extract the positions of the bodies
x1_ab = y(:,1);
y1_ab = y(:,2);
z1_ab = y(:,3);
x2_ab = y(:,7);
y2_ab = y(:,8);
z2_ab = y(:,9);
x3_ab = y(:,13);
y3_ab = y(:,14);
z3_ab = y(:,15);

% Solve the equations of motion using the Adams-Moulton Method
tic;
y = adams_moulton(@three_body_equations, tspan, y0, dt, G, m);
pt_am = toc

% Extract the positions of the bodies
x1_am = y(:,1);
y1_am = y(:,2);
z1_am = y(:,3);
x2_am = y(:,7);
y2_am = y(:,8);
z2_am = y(:,9);
x3_am = y(:,13);
y3_am = y(:,14);
z3_am = y(:,15);

% Set up the 3D plot
figure;
plot3(x1_ie, y1_ie, z1_ie, 'r-','HandleVisibility','off')
hold on
plot3(x2_ie, y2_ie, z2_ie, 'r-','HandleVisibility','off')
plot3(x3_ie, y3_ie, z3_ie, 'r-')

plot3(x1_ee, y1_ee, z1_ee, 'g-','HandleVisibility','off')
plot3(x2_ee, y2_ee, z2_ee, 'g-','HandleVisibility','off')
plot3(x3_ee, y3_ee, z3_ee, 'g-')

plot3(x1_rk2, y1_rk2, z1_rk2, 'm-','HandleVisibility','off')
plot3(x2_rk2, y2_rk2, z2_rk2, 'm-','HandleVisibility','off')
plot3(x3_rk2, y3_rk2, z3_rk2, 'm-')

plot3(x1_rk4, y1_rk4, z1_rk4, 'k--','HandleVisibility','off')
plot3(x2_rk4, y2_rk4, z2_rk4, 'k--','HandleVisibility','off')
plot3(x3_rk4, y3_rk4, z3_rk4, 'k--')

plot3(x1_mm, y1_mm, z1_mm, 'c-','HandleVisibility','off')
plot3(x2_mm, y2_mm, z2_mm, 'c-','HandleVisibility','off')
plot3(x3_mm, y3_mm, z3_mm, 'c-')

plot3(x1_ab, y1_ab, z1_ab, 'y-','HandleVisibility','off')
plot3(x2_ab, y2_ab, z2_ab, 'y-','HandleVisibility','off')
plot3(x3_ab, y3_ab, z3_ab, 'y-')

plot3(x1_am, y1_am, z1_am, 'r--','HandleVisibility','off')
plot3(x2_am, y2_am, z2_am, 'r--','HandleVisibility','off')
plot3(x3_am, y3_am, z3_am, 'r--')

grid on;
axis equal;
xlabel('X');
ylabel('Y');
zlabel('Z');
title('Trajectories of Three Bodies');
legend('Implicit Euler','Explicit Euler','RK2','Modified Midpoint','RK4','Adams-Bashford','Adams-Moulton')
view(3); % Set the view to 3D

function y = implicit_euler(f, tspan, y0, dt)
    y = zeros(length(tspan), length(y0));
    y(1,:) = y0;
    options = optimoptions('fsolve', 'Display', 'none');
    for i = 2:length(tspan)
        F = @(y_next) y_next - y(i-1,:).' - dt * f(tspan(i), y_next); % Remove transpose from f output
        y(i,:) = fsolve(F, y(i-1,:).', options).'; % Transpose the result of fsolve
    end
end

function y = explicit_euler(f, tspan, y0, dt)
    y = zeros(length(tspan), length(y0));
    y(1,:) = y0;
    for i = 2:length(tspan)
        y(i,:) = y(i-1,:) + dt * f(tspan(i-1), y(i-1,:).').'; % Ensure the output of f is a row vector
    end
end

function y = midpoint_method(f, tspan, y0, dt)
    y = zeros(length(tspan), length(y0));
    y(1,:) = y0;
    for i = 2:length(tspan)
        k1 = f(tspan(i-1), y(i-1,:).').'; % Ensure the output of f is a row vector
        k2 = f(tspan(i-1) + dt/2, (y(i-1,:) + dt/2 * k1).').'; % Ensure the output of f is a row vector
        y(i,:) = y(i-1,:) + dt * k2;
    end
end

function y = rk4_method(f, tspan, y0, dt)
    y = zeros(length(tspan), length(y0));
    y(1,:) = y0;
    for i = 2:length(tspan)
        k1 = f(tspan(i-1), y(i-1,:).').';
        k2 = f(tspan(i-1) + dt/2, (y(i-1,:) + dt/2 * k1).').';
        k3 = f(tspan(i-1) + dt/2, (y(i-1,:) + dt/2 * k2).').';
        k4 = f(tspan(i-1) + dt, (y(i-1,:) + dt * k3).').';
        y(i,:) = y(i-1,:) + dt/6 * (k1 + 2*k2 + 2*k3 + k4);
    end
end

function y = modified_midpoint_method(f, tspan, y0, dt)
    y = zeros(length(tspan), length(y0));
    y(1,:) = y0;
    for i = 2:length(tspan)
        k1 = f(tspan(i-1), y(i-1,:).').';
        k2 = f(tspan(i-1) + dt/2, (y(i-1,:) + dt/2 * k1).').';
        k3 = f(tspan(i-1) + dt, (y(i-1,:) + dt * k2 - dt/2 * k1).').';
        y(i,:) = y(i-1,:) + dt/6 * (k1 + 4*k2 + k3);
    end
end

function y = adams_bashforth(f, tspan, y0, dt, G, m)
    y = zeros(length(y0), length(tspan));
    y(:,1) = y0';
    % Bootstrap with Euler's method for the first few steps
    for i = 1:3
        y(:, i+1) = y(:, i) + dt * f(tspan(i), y(:, i), G, m);
    end
    % Adams-Bashforth 4-step method
    for i = 4:length(tspan)-1
        F1 = f(tspan(i), y(:, i), G, m);
        F2 = f(tspan(i-1), y(:, i-1), G, m);
        F3 = f(tspan(i-2), y(:, i-2), G, m);
        F4 = f(tspan(i-3), y(:, i-3), G, m);
        y(:, i+1) = y(:, i) + dt/24 * (55*F1 - 59*F2 + 37*F3 - 9*F4);
    end
    y = y'; % Transpose y to match the expected output format
end

function y = adams_moulton(f, tspan, y0, dt, G, m)
    y = zeros(length(tspan), length(y0));
    y(1,:) = y0;
    % Start by using a different method for the first two steps, e.g., Euler's method
    for i = 2:3
        f_now = f(tspan(i-1), y(i-1,:)', G, m);
        y(i,:) = y(i-1,:) + dt * f_now';
    end

    % Perform the Adams-Moulton 3-step method
    for i = 4:length(tspan)
        % Predictor step using Adams-Bashforth 3-step method
        f_k_minus_1 = f(tspan(i-1), y(i-1,:)', G, m);
        f_k_minus_2 = f(tspan(i-2), y(i-2,:)', G, m);
        f_k_minus_3 = f(tspan(i-3), y(i-3,:)', G, m);
        y_predictor = y(i-1,:) + dt/24 * (55*f_k_minus_1 - 59*f_k_minus_2 + 37*f_k_minus_3 - 9*f_k_minus_3)';
        
        % Corrector step using Adams-Moulton 3-step method
        % This requires solving an implicit equation, typically with an iterative solver like fsolve
        corrector_func = @(y_next) y_next - (y(i-1,:)' + dt/24 * (9*f(tspan(i), y_next, G, m) + 19*f_k_minus_1 - 5*f_k_minus_2 + f_k_minus_3));
        y_predictor_column = y_predictor';
        y(i,:) = fsolve(corrector_func, y_predictor_column, optimoptions('fsolve', 'Display', 'off'))';
    end
end

function dydt = three_body_equations(t, y, G, m)
    % Unpack the input vector
    r1 = y(1:3);
    v1 = y(4:6);
    r2 = y(7:9);
    v2 = y(10:12);
    r3 = y(13:15);
    v3 = y(16:18);
    
    % Compute the accelerations
    a1 = G * m(2) * (r2 - r1) / norm(r2 - r1)^3 + G * m(3) * (r3 - r1) / norm(r3 - r1)^3;
    a2 = G * m(1) * (r1 - r2) / norm(r1 - r2)^3 + G * m(3) * (r3 - r2) / norm(r3 - r2)^3;
    a3 = G * m(1) * (r1 - r3) / norm(r1 - r3)^3 + G * m(2) * (r2 - r3) / norm(r2 - r3)^3;
    
    % Pack the output vector
    dydt = [v1; a1; v2; a2; v3; a3];
end