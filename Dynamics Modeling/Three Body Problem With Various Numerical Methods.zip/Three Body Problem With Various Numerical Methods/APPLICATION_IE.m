clear; close all; clc

% Disable warning
warning('off', 'MATLAB:table:ModifiedAndSavedVarnames');

% Import NT1-23 Data
data_NT = struct2cell(table2struct(readtable('NT1_DATA_ORBIT_HOUR.txt')));
rv_NT = data_NT(5:10,:)';
rv_NT = cellfun(@(x) str2double(strrep(x, ',', '')), rv_NT);
rv_NT = rv_NT*1000;
r_NT = rv_NT(:,1:3);

% Import Earth Data
data_Earth = struct2cell(table2struct(readtable('EARTH_DATA_ORBIT_HOUR.txt')));
rv_Earth = data_Earth(5:10,:)';
rv_Earth = cellfun(@(x) str2double(strrep(x, ',', '')), rv_Earth);
rv_Earth = rv_Earth*1000;

% Parameters
G = 6.67430e-11; % Gravitational constant in m^3 kg^-1 s^-2
m = [5.972e24, 5.2e4, 1.989e30]; % Masses of the Earth, NT1, and Sun in kg
dt = 60*60; % Time step in seconds (one hour)
tspan = 0:dt:1096*24*3600; % Time span for the simulation (30 days)
AU = 1.496e+11;

% Initial Conditions
r1 = [rv_Earth(1,1), rv_Earth(1,2), rv_Earth(1,3)]; % Earth position
v1 = [rv_Earth(1,4), rv_Earth(1,5), rv_Earth(1,6)]; % Earth velocity in m/s
r2 = [rv_NT(1,1), rv_NT(1,2), rv_NT(1,3)]; % Moon position
v2 = [rv_NT(1,4), rv_NT(1,5), rv_NT(1,6)]; % Moon velocity in m/s
r3 = [0, 0, 0]; % Sun position
v3 = [0, 0, 0]; % Sun velocity
y0 = [r1, v1, r2, v2, r3, v3];

% Solve the equations of motion using the RK4 Method
y = implicit_euler(@(t, y) three_body_equations(t, y, G, m), tspan, y0, dt);

% Extract the positions of the bodies
x1 = y(:,1);
y1 = y(:,2);
z1 = y(:,3);
x2 = y(:,7);
y2 = y(:,8);
z2 = y(:,9);
x3 = y(:,13);
y3 = y(:,14);
z3 = y(:,15);

% Set up the 3D plot
figure(1);
plot3(x1, y1, z1, 'r-', x2, y2, z2, 'g-', x3, y3, z3, 'b-',...
      r_NT(:,1), r_NT(:,2), r_NT(:,3), 'r--');
grid on;
axis equal;
xlabel('X');
ylabel('Y');
zlabel('Z');
title('Trajectories of Earth, NT1-23, and Sun using IE Method');
legend('Earth','NT1-23','Sun','NT1-23 DATA')
hold on; % Hold on to the existing plot
sun_radius = 695700e3*10; % Radius of the Sun in meters
[sx, sy, sz] = sphere; % Generate a unit sphere
surf(sun_radius*sx + x3(1), sun_radius*sy + y3(1), sun_radius*sz + z3(1), 'FaceColor', 'y', 'EdgeColor', 'none','HandleVisibility','off'); % Scale and translate sphere
light; lighting phong; % Add lighting effects to make it look more spherical
hold off;
view(3); % Set the view to 3D

% Analysis
r2 = [x2 y2 z2];
r21 = r2-r_NT;
dr = zeros(length(r21),1);
for k = 1:length(r21)
    dr(k) = norm(r21(k));
end
max(dr)/AU
mean(dr)/AU

function y = implicit_euler(f, tspan, y0, dt)
    y = zeros(length(tspan), length(y0));
    y(1,:) = y0;
    options = optimoptions('fsolve', 'Display', 'none');
    for i = 2:length(tspan)
        F = @(y_next) y_next - y(i-1,:).' - dt * f(tspan(i), y_next); % Remove transpose from f output
        y(i,:) = fsolve(F, y(i-1,:).', options).'; % Transpose the result of fsolve
    end
end

function dydt = three_body_equations(t, y, G, m)
    % Unpack the input vector
    r1 = y(1:3);
    v1 = y(4:6);
    r2 = y(7:9);
    v2 = y(10:12);
    r3 = y(13:15);
    v3 = y(16:18);
    
    % Compute the accelerations
    a1 = G * m(3) * (r3 - r1) / norm(r3 - r1)^3;
    a2 = G * m(1) * (r1 - r2) / norm(r1 - r2)^3 + G * m(3) * (r3 - r2) / norm(r3 - r2)^3;
    a3 = G * m(1) * (r1 - r3) / norm(r1 - r3)^3;
    
    % Pack the output vector as a column vector
    dydt = [v1; a1; v2; a2; v3; a3];
end